#!/usr/bin/python
import os
os.system('cd ~/RaspberryPi/src; /usr/bin/python /home/pi/RaspberryPi/src/daily_report.py')
